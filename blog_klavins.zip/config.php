<?php

return [
    "host" => "localhost",
    "dbname" => "blog_klavins",
    "user" => "root",
    "password" => "",
    "charset" => "utf8mb4"
];